using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject BeeFab;
    // Start is called before the first frame update
    private void Awake()
    {
        //GameObject Bee =Instantiate<GameObject>(BeeFab);
        //Bee.transform.position = this.transform.position;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
