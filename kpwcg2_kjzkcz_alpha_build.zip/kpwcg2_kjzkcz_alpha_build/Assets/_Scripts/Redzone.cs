using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Redzone : MonoBehaviour
{
    public GameObject Bee;
    public GameObject sp;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("Bee IN");
        Destroy(Bee);
        GameObject newBee;
        newBee=Instantiate<GameObject>(Bee);
        newBee.transform.position = sp.transform.position;
    }
}
